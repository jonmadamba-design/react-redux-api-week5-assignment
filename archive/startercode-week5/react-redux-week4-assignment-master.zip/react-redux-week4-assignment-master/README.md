# react-redux-week4-assignment
submission for nucamp react week4 assignment

Workshop Assignment:
update week3 starter to use redux for delete and add user functionality 
Starter project: Week-4-Starter-Code-Nucamp-React-Master
Clone Repo from Instructor: https://github.com/AaronMacken/Week-4-Starter-Code-Nucamp-React.git
